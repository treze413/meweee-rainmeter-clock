-- =========================================
-- MeWeee Countdown Lua (FINAL)
-- =========================================

local targetTime
local startTime

function Initialize()
    startTime = os.time({
        year  = 2026,
        month = 1,
        day   = 1,
        hour  = 0,
        min   = 0,
        sec   = 0
    })

    targetTime = os.time({
        year  = 2027,
        month = 12,
        day   = 31,
        hour  = 23,
        min   = 59,
        sec   = 59
    })
end

function Update()
    local now = os.time()
    local secondsLeft = os.difftime(targetTime, now)
    local daysLeft = math.floor(secondsLeft / 86400)
    if daysLeft < 0 then daysLeft = 0 end
    return daysLeft
end


function GetBarColor()
    local now = os.time()
    local totalSeconds = os.difftime(targetTime, startTime)
    local remainingSeconds = os.difftime(targetTime, now)
    if remainingSeconds < 0 then remainingSeconds = 0 end

    local percent = (remainingSeconds / totalSeconds) * 100

    if percent > 50 then
        return "80,200,120,230"
    elseif percent > 30 then
        return "230,200,80,230"
    elseif percent > 20 then
        return "230,140,60,230"
    else
        return "230,80,80,230"
    end
end
